package com.hackjail;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.NotNull;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class HackJailPlugin extends JavaPlugin implements Listener {

    /** ชื่อโลกที่ใช้ขัง */
    static final String EPIC_WORLD = "EPIC";
    /** พิกัดห้องขัง (จะวางตรงกลางบล็อกให้เอง) */
    static final double JAIL_X = -41, JAIL_Y = 46, JAIL_Z = -22;
    /** ข้อความบนหัวผู้ถูกขัง */
    static final String TAG_TEXT = "hack";
    /** ความสูงของข้อความ hack เหนือหัว ปรับได้ถ้าสูง/ต่ำไป */
    static final float TAG_Y_OFFSET = 0.3f;

    private static final String TEAM_NAME = "hj_hack";
    private static final String ADMIN_PERM = "hackjail.admin";

    private final Map<UUID, JailEntry> jailed = new LinkedHashMap<>();
    /** คนที่ถูกปล่อยตอนออฟไลน์ รอวาปกลับตอนเข้าเกม */
    private final Map<UUID, JailEntry> pending = new HashMap<>();
    private final Map<UUID, UUID> tags = new HashMap<>();
    private final Set<UUID> bypassTp = new HashSet<>();
    private File dataFile;

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onEnable() {
        dataFile = new File(getDataFolder(), "data.yml");
        getDataFolder().mkdirs();
        load();
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 20L, 20L);
    }

    @Override
    public void onDisable() {
        for (UUID id : new ArrayList<>(jailed.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                restoreAbilities(p, jailed.get(id));
            }
        }
        for (UUID id : new ArrayList<>(tags.keySet())) {
            removeTag(id);
        }
        syncTeams(true);
        save();
    }

    // ------------------------------------------------------------------ commands

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                             @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission(ADMIN_PERM)) {
            sender.sendMessage(Component.text("คุณไม่มีสิทธิ์ใช้คำสั่งนี้", NamedTextColor.RED));
            return true;
        }
        if (cmd.getName().equalsIgnoreCase("hack")) {
            if (args.length != 1) {
                sender.sendMessage(Component.text("ใช้: /hack <ชื่อผู้เล่น>", NamedTextColor.RED));
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage(Component.text("ไม่พบผู้เล่นออนไลน์ชื่อ " + args[0], NamedTextColor.RED));
                return true;
            }
            hack(sender, target);
            return true;
        }

        // /dehack
        if (args.length >= 1) {
            UUID id = findJailedByName(args[0]);
            if (id == null) {
                sender.sendMessage(Component.text(args[0] + " ไม่ได้ถูกขังอยู่", NamedTextColor.RED));
            } else {
                release(id, sender);
            }
            return true;
        }
        if (!(sender instanceof Player staff)) {
            if (jailed.isEmpty()) {
                sender.sendMessage("ไม่มีคนถูกขัง");
            } else {
                StringBuilder sb = new StringBuilder("คนที่ถูกขัง: ");
                jailed.values().forEach(e -> sb.append(e.name).append(' '));
                sender.sendMessage(sb.toString());
            }
            return true;
        }
        openGui(staff);
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd,
                                      @NotNull String alias, @NotNull String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length != 1 || !sender.hasPermission(ADMIN_PERM)) {
            return out;
        }
        String prefix = args[0].toLowerCase();
        if (cmd.getName().equalsIgnoreCase("hack")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!jailed.containsKey(p.getUniqueId()) && p.getName().toLowerCase().startsWith(prefix)) {
                    out.add(p.getName());
                }
            }
        } else {
            for (JailEntry e : jailed.values()) {
                if (e.name.toLowerCase().startsWith(prefix)) {
                    out.add(e.name);
                }
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ core: hack / release

    private void hack(CommandSender sender, Player target) {
        UUID id = target.getUniqueId();
        if (jailed.containsKey(id)) {
            sender.sendMessage(Component.text(target.getName() + " ถูกขังอยู่แล้ว", NamedTextColor.RED));
            return;
        }
        World epic = epicWorld();
        if (epic == null) {
            sender.sendMessage(Component.text("ไม่พบโลกชื่อ " + EPIC_WORLD, NamedTextColor.RED));
            return;
        }

        JailEntry entry = JailEntry.of(target);
        target.leaveVehicle();
        if (!target.teleport(jailLocation(epic, target.getLocation()))) {
            sender.sendMessage(Component.text("วาป " + target.getName() + " ไม่สำเร็จ", NamedTextColor.RED));
            return;
        }

        jailed.put(id, entry);
        freeze(target);
        save();
        syncTeams(false);
        sendJailTitle(target);
        // ผู้โดยสาร (ป้าย hack) ต้องเสกหลังวาปเสร็จ
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (target.isOnline() && jailed.containsKey(id)) {
                ensureTag(target);
            }
        }, 2L);

        sender.sendMessage(Component.text("ขัง " + target.getName() + " ไว้ในโลก " + EPIC_WORLD + " แล้ว", NamedTextColor.GREEN));
    }

    private boolean release(UUID id, CommandSender by) {
        JailEntry entry = jailed.remove(id);
        if (entry == null) {
            return false;
        }
        removeTag(id);
        Player p = Bukkit.getPlayer(id);
        if (p != null) {
            restoreAbilities(p, entry);
            p.clearTitle();
            teleportToOrigin(p, entry);
            p.sendMessage(Component.text("คุณถูกปล่อยตัวแล้ว", NamedTextColor.GREEN));
        } else {
            pending.put(id, entry);
        }
        syncTeams(false);
        save();
        by.sendMessage(Component.text("ปล่อย " + entry.name + " แล้ว"
                + (p == null ? " (ออฟไลน์ จะวาปกลับตอนเข้าเกม)" : ""), NamedTextColor.GREEN));
        return true;
    }

    private UUID findJailedByName(String name) {
        for (Map.Entry<UUID, JailEntry> e : jailed.entrySet()) {
            if (e.getValue().name.equalsIgnoreCase(name)) {
                return e.getKey();
            }
        }
        return null;
    }

    private void teleportToOrigin(Player p, JailEntry entry) {
        Location origin = entry.origin();
        if (origin == null) {
            origin = Bukkit.getWorlds().get(0).getSpawnLocation();
        }
        p.teleport(origin);
    }

    // ------------------------------------------------------------------ freeze helpers

    private void freeze(Player p) {
        p.setWalkSpeed(0f);
        p.setFlySpeed(0f);
        p.setVelocity(new Vector());
        if (p.getGameMode() == org.bukkit.GameMode.SURVIVAL || p.getGameMode() == org.bukkit.GameMode.ADVENTURE) {
            p.setFlying(false);
            p.setAllowFlight(false);
        }
    }

    private void restoreAbilities(Player p, JailEntry entry) {
        p.setWalkSpeed(entry.walk);
        p.setFlySpeed(entry.fly);
    }

    private void sendJailTitle(Player p) {
        p.showTitle(Title.title(
                Component.text("ออกเกม = แบน", NamedTextColor.RED, TextDecoration.BOLD),
                Component.empty(),
                Title.Times.times(Duration.ZERO, Duration.ofMillis(2500), Duration.ZERO)));
    }

    // ------------------------------------------------------------------ name tag ("hack" above head)

    private void ensureTag(Player p) {
        UUID tagId = tags.get(p.getUniqueId());
        if (tagId != null) {
            Entity existing = Bukkit.getEntity(tagId);
            if (existing instanceof TextDisplay td && td.isValid() && p.getPassengers().contains(td)) {
                return;
            }
        }
        removeTag(p.getUniqueId());

        TextDisplay display = p.getWorld().spawn(p.getLocation(), TextDisplay.class, d -> {
            d.text(Component.text(TAG_TEXT, NamedTextColor.RED, TextDecoration.BOLD));
            d.setBillboard(Display.Billboard.CENTER);
            d.setPersistent(false);
            d.setTransformation(new Transformation(
                    new Vector3f(0f, TAG_Y_OFFSET, 0f),
                    new AxisAngle4f(),
                    new Vector3f(1f, 1f, 1f),
                    new AxisAngle4f()));
        });
        p.addPassenger(display);
        p.hideEntity(this, display); // เจ้าตัวไม่ต้องเห็นป้ายลอยของตัวเอง
        tags.put(p.getUniqueId(), display.getUniqueId());
    }

    private void removeTag(UUID playerId) {
        UUID tagId = tags.remove(playerId);
        if (tagId != null) {
            Entity e = Bukkit.getEntity(tagId);
            if (e != null) {
                e.remove();
            }
        }
    }

    /** ซ่อนชื่อจริงบนหัวของผู้ถูกขัง (ผ่านทีมสกอร์บอร์ด) ให้เหลือแค่ป้าย hack */
    private void syncTeams(boolean clearAll) {
        Set<Scoreboard> boards = Collections.newSetFromMap(new IdentityHashMap<>());
        if (Bukkit.getScoreboardManager() != null) {
            boards.add(Bukkit.getScoreboardManager().getMainScoreboard());
        }
        for (Player p : Bukkit.getOnlinePlayers()) {
            boards.add(p.getScoreboard());
        }
        Set<String> names = new HashSet<>();
        if (!clearAll) {
            for (UUID id : jailed.keySet()) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) {
                    names.add(p.getName());
                }
            }
        }
        for (Scoreboard sb : boards) {
            Team team = sb.getTeam(TEAM_NAME);
            if (names.isEmpty()) {
                if (team != null) {
                    team.unregister();
                }
                continue;
            }
            if (team == null) {
                team = sb.registerNewTeam(TEAM_NAME);
            }
            team.setOption(Team.Option.NAME_TAG_VISIBILITY, Team.OptionStatus.NEVER);
            for (String entry : new ArrayList<>(team.getEntries())) {
                if (!names.contains(entry)) {
                    team.removeEntry(entry);
                }
            }
            for (String n : names) {
                if (!team.hasEntry(n)) {
                    team.addEntry(n);
                }
            }
        }
    }

    // ------------------------------------------------------------------ periodic tick (every second)

    private void tick() {
        World epic = epicWorld();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (inEpic(p)) {
                heal(p);
            }
        }
        for (UUID id : new ArrayList<>(jailed.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) {
                continue;
            }
            if (epic != null) {
                Location l = p.getLocation();
                Location jail = jailLocation(epic, l);
                if (l.getWorld() != epic || l.distanceSquared(jail) > 4) {
                    bypassTp.add(id);
                    try {
                        p.leaveVehicle();
                        p.teleport(jail);
                    } finally {
                        bypassTp.remove(id);
                    }
                }
            }
            freeze(p);
            ensureTag(p);
            sendJailTitle(p);
        }
        syncTeams(false);
    }

    private void heal(Player p) {
        p.setFoodLevel(20);
        p.setSaturation(20f);
        AttributeInstance max = p.getAttribute(Attribute.MAX_HEALTH);
        if (max != null && p.getHealth() < max.getValue()) {
            p.setHealth(max.getValue());
        }
    }

    // ------------------------------------------------------------------ events: jail rules

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!jailed.containsKey(e.getPlayer().getUniqueId())) {
            return;
        }
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) {
            return;
        }
        if (from.getX() == to.getX() && from.getY() == to.getY() && from.getZ() == to.getZ()) {
            return; // แค่หมุนหัว อนุญาต
        }
        Location fixed = from.clone();
        fixed.setYaw(to.getYaw());
        fixed.setPitch(to.getPitch());
        e.setTo(fixed);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (jailed.containsKey(id) && !bypassTp.contains(id)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPortal(PlayerPortalEvent e) {
        if (jailed.containsKey(e.getPlayer().getUniqueId())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onJailedCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (jailed.containsKey(p.getUniqueId()) && !p.isOp()) {
            e.setCancelled(true);
            p.sendMessage(Component.text("คุณถูกขังอยู่ ใช้คำสั่งไม่ได้", NamedTextColor.RED));
        }
    }

    // ------------------------------------------------------------------ events: EPIC world rules

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && (inEpic(p) || jailed.containsKey(p.getUniqueId()))) {
            e.setCancelled(true); // เลือดไม่ลด และตีกันไม่ได้
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && inEpic(p)) {
            e.setCancelled(true);
            p.setFoodLevel(20);
            p.setSaturation(20f);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        boolean jailedPlayer = jailed.containsKey(p.getUniqueId());
        if (jailedPlayer || (inEpic(p) && !p.isOp())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        if (inEpic(e.getPlayer())) {
            heal(e.getPlayer());
        }
    }

    // ------------------------------------------------------------------ events: join / quit

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.isOnline()) {
                return;
            }
            JailEntry released = pending.remove(id);
            if (released != null) {
                restoreAbilities(p, released);
                p.clearTitle();
                teleportToOrigin(p, released);
                p.sendMessage(Component.text("คุณถูกปล่อยตัวแล้ว", NamedTextColor.GREEN));
                save();
                return;
            }
            if (jailed.containsKey(id)) {
                tick(); // จัดตำแหน่ง ป้าย ชื่อ ทันที
            }
        }, 5L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        removeTag(e.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------ GUI

    private void openGui(Player staff) {
        if (jailed.isEmpty()) {
            staff.closeInventory();
            staff.sendMessage(Component.text("ตอนนี้ไม่มีคนถูกขัง", NamedTextColor.YELLOW));
            return;
        }
        List<UUID> ids = new ArrayList<>(jailed.keySet());
        if (ids.size() > 54) {
            ids = ids.subList(0, 54);
        }
        int rows = Math.max(1, (ids.size() + 8) / 9);
        HackGui gui = new HackGui(ids);
        Inventory inv = Bukkit.createInventory(gui, rows * 9,
                Component.text("คนที่ถูกขัง (คลิกเพื่อปล่อย)", NamedTextColor.DARK_RED));
        gui.inventory = inv;

        int slot = 0;
        for (UUID id : ids) {
            JailEntry entry = jailed.get(id);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            OfflinePlayer off = Bukkit.getOfflinePlayer(id);
            meta.setOwningPlayer(off);
            meta.displayName(Component.text(entry.name, NamedTextColor.RED)
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(
                    Component.text("คลิกเพื่อปล่อยตัว", NamedTextColor.GREEN)
                            .decoration(TextDecoration.ITALIC, false),
                    Component.text(String.format("จะวาปกลับไป: %s %d %d %d",
                                    entry.world, (int) Math.floor(entry.x),
                                    (int) Math.floor(entry.y), (int) Math.floor(entry.z)),
                            NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
            head.setItemMeta(meta);
            inv.setItem(slot++, head);
        }
        staff.openInventory(inv);
    }

    @EventHandler
    public void onGuiClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof HackGui gui)) {
            return;
        }
        e.setCancelled(true);
        if (e.getClickedInventory() != e.getView().getTopInventory()) {
            return;
        }
        if (!(e.getWhoClicked() instanceof Player staff) || !staff.hasPermission(ADMIN_PERM)) {
            return;
        }
        int slot = e.getRawSlot();
        if (slot < 0 || slot >= gui.ids.size()) {
            return;
        }
        UUID id = gui.ids.get(slot);
        release(id, staff);
        Bukkit.getScheduler().runTask(this, () -> openGui(staff));
    }

    @EventHandler
    public void onGuiDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof HackGui) {
            e.setCancelled(true);
        }
    }

    private static final class HackGui implements InventoryHolder {
        final List<UUID> ids;
        Inventory inventory;

        HackGui(List<UUID> ids) {
            this.ids = ids;
        }

        @Override
        public @NotNull Inventory getInventory() {
            return inventory;
        }
    }

    // ------------------------------------------------------------------ world helpers

    private World epicWorld() {
        for (World w : Bukkit.getWorlds()) {
            if (w.getName().equalsIgnoreCase(EPIC_WORLD)) {
                return w;
            }
        }
        return null;
    }

    private boolean inEpic(Player p) {
        return p.getWorld().getName().equalsIgnoreCase(EPIC_WORLD);
    }

    /** จุดขัง (กลางบล็อก) โดยคงทิศที่หันอยู่ไว้ */
    private Location jailLocation(World epic, Location facing) {
        return new Location(epic, JAIL_X + 0.5, JAIL_Y, JAIL_Z + 0.5, facing.getYaw(), facing.getPitch());
    }

    // ------------------------------------------------------------------ persistence

    private static final class JailEntry {
        final String name;
        final String world;
        final double x, y, z;
        final float yaw, pitch;
        final float walk, fly;

        JailEntry(String name, String world, double x, double y, double z,
                  float yaw, float pitch, float walk, float fly) {
            this.name = name;
            this.world = world;
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = yaw;
            this.pitch = pitch;
            this.walk = walk;
            this.fly = fly;
        }

        static JailEntry of(Player p) {
            Location l = p.getLocation();
            float walk = p.getWalkSpeed() <= 0f ? 0.2f : p.getWalkSpeed();
            float fly = p.getFlySpeed() <= 0f ? 0.1f : p.getFlySpeed();
            return new JailEntry(p.getName(), l.getWorld().getName(),
                    l.getX(), l.getY(), l.getZ(), l.getYaw(), l.getPitch(), walk, fly);
        }

        Location origin() {
            World w = Bukkit.getWorld(world);
            return w == null ? null : new Location(w, x, y, z, yaw, pitch);
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        write(y, "jailed", jailed);
        write(y, "pending", pending);
        try {
            y.save(dataFile);
        } catch (IOException ex) {
            getLogger().warning("บันทึก data.yml ไม่สำเร็จ: " + ex.getMessage());
        }
    }

    private void write(YamlConfiguration y, String root, Map<UUID, JailEntry> map) {
        for (Map.Entry<UUID, JailEntry> e : map.entrySet()) {
            String p = root + "." + e.getKey() + ".";
            JailEntry j = e.getValue();
            y.set(p + "name", j.name);
            y.set(p + "world", j.world);
            y.set(p + "x", j.x);
            y.set(p + "y", j.y);
            y.set(p + "z", j.z);
            y.set(p + "yaw", j.yaw);
            y.set(p + "pitch", j.pitch);
            y.set(p + "walk", j.walk);
            y.set(p + "fly", j.fly);
        }
    }

    private void load() {
        if (!dataFile.exists()) {
            return;
        }
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        read(y.getConfigurationSection("jailed"), jailed);
        read(y.getConfigurationSection("pending"), pending);
    }

    private void read(ConfigurationSection sec, Map<UUID, JailEntry> into) {
        if (sec == null) {
            return;
        }
        for (String key : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(key);
            if (s == null) {
                continue;
            }
            try {
                into.put(UUID.fromString(key), new JailEntry(
                        s.getString("name", key),
                        s.getString("world", "world"),
                        s.getDouble("x"), s.getDouble("y"), s.getDouble("z"),
                        (float) s.getDouble("yaw"), (float) s.getDouble("pitch"),
                        (float) s.getDouble("walk", 0.2), (float) s.getDouble("fly", 0.1)));
            } catch (IllegalArgumentException ignored) {
                // key ไม่ใช่ UUID ข้ามไป
            }
        }
    }
}
